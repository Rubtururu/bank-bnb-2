<!DOCTYPE HTML>
<html>
<head>
<link rel="icon" type="image/x-icon" href="favicon.ico">
<title>BNB REWARD PLANET</title>
<meta charset="utf-8">
<link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:400,400italic,700,900" rel="stylesheet">
<script src="js/jquery-1.9.1.min.js"></script>
<script src="css/5grid/init.js?use=mobile,desktop,1000px&amp;mobileUI=1&amp;mobileUI.theme=none&amp;mobileUI.titleBarHeight=0"></script>
<script src="js/jquery.dropotron-1.2.js"></script>
<script src="js/init.js"></script>
<noscript>
<link rel="stylesheet" href="css/5grid/core.css">
<link rel="stylesheet" href="css/5grid/core-desktop.css">
<link rel="stylesheet" href="css/5grid/core-1200px.css">
<link rel="stylesheet" href="css/5grid/core-noscript.css">
<link rel="stylesheet" href="css/style.css">
<link rel="stylesheet" href="css/style-desktop.css">
<link rel="stylesheet" href="/css/style-mobile.css">
<link rel="stylesheet" href="/css/dash.css">
<link rel="shortcut icon" href="favicon.ico" type="image/x-icon"/>
</noscript>
<!--[if lte IE 8]>
<link rel="stylesheet" href="css/ie8.css">
<![endif]-->
<script src="https://kit.fontawesome.com/13f7723f0d.js" crossorigin="anonymous"></script>
</head>
<body class="homepage">
<div id="header-wrapper" class="wrapper">
  <div class="5grid-layout">
    <div class="row">
      <div class="12u">
        <div id="header">
          <div id="logo">
            <h1><a href="#" class="mobileUI-site-name">BNB REWARD PLANET</a></h1>
            <span class="byline">Launching Your Crypto Profits to Infinity and Beyond!</span></div>
          <nav id="nav" class="mobileUI-site-nav">
            <ul>
              <li class="current_page_item"><a href="index.html">Home</a></li>
              <li> <span>About</span>
                <ul>
                  <li><a href="#howTo">How To</a></li>
                  <li><a href="/whitepaper.html">Whitepaper</a></li>
                  <li><a href="https://mobile.twitter.com/bnbrewardplanet">X(Twitter)</a></li>
                  <li><a href="https://t.me/bnbrewardplanet">Telegram</a></li>
                </ul>
              </li>
              <li><a href="#dash">Dashboard</a></li>
              <!-- <li><a href="#">Audit</a></li> -->
              <li><a href="#howTo">FAQS</a></li>
            </ul>
          </nav>
        </div>
      </div>
    </div>
  </div>
</div>
<div id="intro-wrapper" class="wrapper wrapper-style1">
  <div class="title">The Introduction</div>
  <div class="5grid-layout">
    <div class="row">
      <div class="12u">
        <section id="intro">
          <p class="style1">So in case you were wondering what this is all about ...</p>
          <p class="style2"> Unveiling The Planet <br class="mobileUI-blank">
            Of Passive Income : <a href="#" class="">Where Rewards Orbit And Profit Florish!</a> </p>
          <p class="style3">Introducing <strong>BNB Reward Planet</strong>, the ultimate destination for <strong>BNB Coin Holders</strong> seeking a seamless blend of <strong>Passive Income</strong>, and financial participation. Experience the fusion of investment and daily earnings like never before &ndash; join us on Bnb Reward Planet and let your BNB coins thrive!</p>
          <ul class="actions">
            <li><a id="connectBtn" class="button button-style3 button-big">Connect Wallet</a></li>
          </ul>
        </section>
      </div>
    </div>
  </div>
</div>
<div class="wrapper wrapper-style2">
  <div id="dash" class="title">Dashboard</div>
  <div class="5grid-layout">
    <div class="row">
      <div class="12u">
        <!-- <div id="main"> <a href="#" class="image image-featured"> <img src="images/pic01.jpg" alt=""></a> -->
          <section id="features">
            <header class="style1">
              <h2 id="connectBtn1">Connect Your Wallet</h2>
              <p class="byline" style="color: #fff;">Double-check the website URL to make sure you’re on the correct platform before proceeding with wallet connection! </p>
            </header>
            <div class="MainContai MuiContainer-root MuiContainer-maxWidthLg css-1qsxih2">
              <div class="MuiGrid-root MuiGrid-container MuiGrid-spacing-xs-2 css-b965al">
                <div class="MuiGrid-root MuiGrid-item MuiGrid-grid-xs-12 MuiGrid-grid-md-6 css-iol86l">
                  <div class="MuiBox-root css-10klw3m">
                    <div class="MuiBox-root css-15m6yw0">
                      <div class="MuiBox-root css-gg4vpm">
                        <div class="MuiBox-root css-0">
                          <h6 class="MuiTypography-root MuiTypography-subtitle1 MuiTypography-gutterBottom css-g99uzl">Stake</h6>
                          <p class="MuiTypography-root MuiTypography-body2 css-nu067e">Amount to Stake</p>
                        </div>
                      </div>
                      <div class="MuiBox-root css-10snqmj">
                        <div class="MuiFormControl-root MuiTextField-root css-7m3oqe" style="background: linear-gradient(270.69deg, rgb(33, 33, 33) 22.1%, rgb(61, 61, 61) 100%); box-shadow: rgba(0, 0, 0, 0.5) 0px 4px 10px, rgba(255, 255, 255, 0.25) 0px 2px 4px inset; border-radius: 20px;">
                          <div class="MuiInputBase-root MuiOutlinedInput-root MuiInputBase-colorPrimary MuiInputBase-formControl MuiInputBase-adornedEnd css-8xb7f5">
                            <input aria-invalid="false" id="amountInput" placeholder="0.00" type="text" class="MuiInputBase-input MuiOutlinedInput-input MuiInputBase-inputAdornedEnd css-1uvydh2" value="">
                            <div class="MuiStack-root css-u4p24i">
                              <img class="MuiBox-root css-ga5scd" src="/images/bnbcoin.png" height="35" alt="">
                              <button class="MuiButtonBase-root MuiButton-root MuiButton-text MuiButton-textPrimary MuiButton-sizeMedium MuiButton-textSizeMedium MuiButton-root MuiButton-text MuiButton-textPrimary MuiButton-sizeMedium MuiButton-textSizeMedium css-7hwcn1" tabindex="0" type="button" id="depositBtn">Deposit
                                <span class="MuiTouchRipple-root css-w0pj6f"></span>
                              </button>
                            </div>
                            <fieldset aria-hidden="true" class="MuiOutlinedInput-notchedOutline css-igs3ac">
                              <legend class="css-ihdtdm">
                                <span class="notranslate">​</span>
                              </legend>
                            </fieldset>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div class="MuiBox-root css-tx3abr">
                      <div class="MuiBox-root css-gg4vpm">
                        <h6 class="MuiTypography-root MuiTypography-subtitle1 MuiTypography-gutterBottom css-g99uzl">Lottery</h6>
                        <div class="MuiBox-root css-1at4tum" aria-label="View your Wolfpack details here: the team's name, total members, and the collective stake amount. Keep track and observe your Wolfpack's growth.">i</div>
                      </div>
                      <div class="MuiBox-root css-0" style="margin-bottom: 10px;" id="giveAwayPage">Connect to view active lottery.</div>
                      <div id="activeGiveaway">
                        <div class="MuiBox-root css-0" style="display: flex;">
                          <h6>Highest Deposit :</h6>
                          <span style="margin-left: 10px; line-height: 22px;" id="highDeposit">0.00</span>
                        </div>
                        <div class="MuiBox-root css-0" style="display: flex;">
                          <h6>Current Winner :</h6>
                          <span style="margin-left: 10px; line-height: 22px;" id="winnerWallet">0x00000</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div class="MuiBox-root css-gwogd3"><h6 class="MuiTypography-root MuiTypography-subtitle1 MuiTypography-gutterBottom css-1hh2tqi">Your Staking Portfolio</h6><div class="MuiGrid-root MuiGrid-container MuiGrid-spacing-xs-2 css-1jtdd3k"><div class="MuiGrid-root MuiGrid-item MuiGrid-grid-xs-12 MuiGrid-grid-sm-6 MuiGrid-grid-md-4 css-1twzmnh"><div class="MuiBox-root css-axw7ok"><i class="fa-solid fa-coins fa-2xl" style="color: #ffffff; margin-right: 20px;"></i><div class="MuiBox-root css-0"><p class="MuiTypography-root MuiTypography-body2 css-jyusxw">Deposit Balance</p><h6 class="MuiTypography-root MuiTypography-subtitle1 css-18y6ukb" id="totaldeposited">$0.00</h6></div></div></div><div class="MuiGrid-root MuiGrid-item MuiGrid-grid-xs-12 MuiGrid-grid-sm-6 MuiGrid-grid-md-4 css-1twzmnh"><div class="MuiBox-root css-axw7ok"><i class="fa-solid fa-wallet fa-2xl" style="color: #ffffff; margin-right: 20px;"></i><div class="MuiBox-root css-0"><p class="MuiTypography-root MuiTypography-body2 css-jyusxw">Bonus Balance</p><h6 class="MuiTypography-root MuiTypography-subtitle1 css-18y6ukb" id="totalBal">$0.00</h6></div></div></div><div class="MuiGrid-root MuiGrid-item MuiGrid-grid-xs-12 MuiGrid-grid-sm-6 MuiGrid-grid-md-4 css-1twzmnh"><div class="MuiBox-root css-axw7ok"><i class="fa-solid fa-hand-holding-dollar fa-2xl" style="color: #ffffff; margin-right: 20px;"></i><div class="MuiBox-root css-0"><p class="MuiTypography-root MuiTypography-body2 css-jyusxw">Claimable Rewards</p><h6 class="MuiTypography-root MuiTypography-subtitle1 css-18y6ukb" id="totalearned">$0.00</h6></div></div></div><div class="MuiGrid-root MuiGrid-item MuiGrid-grid-xs-12 MuiGrid-grid-sm-6 MuiGrid-grid-md-4 css-1twzmnh"><div class="MuiBox-root css-axw7ok"><i class="fa-solid fa-coins fa-2xl" style="color: #ffffff; margin-right: 20px;"></i><div class="MuiBox-root css-0"><p class="MuiTypography-root MuiTypography-body2 css-jyusxw">Total Withdrawn</p><h6 class="MuiTypography-root MuiTypography-subtitle1 css-18y6ukb" id="paidrewards">$0.00</h6></div></div></div><div class="MuiGrid-root MuiGrid-item MuiGrid-grid-xs-12 MuiGrid-grid-sm-6 MuiGrid-grid-md-4 css-1twzmnh"><div class="MuiBox-root css-axw7ok"><i class="fa-solid fa-coins fa-2xl" style="color: #ffffff; margin-right: 20px;"></i><div class="MuiBox-root css-0"><p class="MuiTypography-root MuiTypography-body2 css-jyusxw">Total Referral Rewards</p><h6 class="MuiTypography-root MuiTypography-subtitle1 css-18y6ukb" id="totalRef">$0.00</h6></div></div></div><div class="MuiGrid-root MuiGrid-item MuiGrid-grid-xs-12 MuiGrid-grid-sm-6 MuiGrid-grid-md-4 css-1twzmnh"><div class="MuiBox-root css-axw7ok"><i class="fa-solid fa-chart-line fa-2xl" style="color: #ffffff; margin-right: 20px;"></i><div class="MuiBox-root css-0"><p class="MuiTypography-root MuiTypography-body2 css-jyusxw">Current Rate</p><h6 class="MuiTypography-root MuiTypography-subtitle1 css-18y6ukb" id="currentRate">0</h6></div></div></div>
              <div style="display: flex; margin: 17px; width: 100%; border: 1px solid; border-radius: 10px; padding: 10px;">
                <div style="width: 100%;">
                  <button style="width: 100%; padding: 12px; border: none; border-radius: 10px; margin-bottom: 10px;" id="addRwd">Compound Returns</button>
                  <span>Time Left for Next action :</span>
                </div>
                <div style="width: 100%; margin-right: 10px;">
                  <button style="width: 100%; padding: 12px; border: none; border-radius: 10px; margin-left: 10px; margin-right: 20px; margin-bottom: 10px;" id="claimBTN">Claim Returns</button>
                <div style="width: 100%;">
                  <div id="timer">24:00:01</div>
                </div>
                </div>
              </div>
              <div style="display: flex; margin: 17px; width: 100%;">
                <div style="width: 100%;">
                  <div class="row">
                    <div class="12u">
                      <ul class="actions">
                        <li>
                          <div id="emergencyWithDepBtn">
                            <input type="emergencyWithdraw" class="button button-style1" value="Emergency Withdraw" >
                          </div>
                        </li>
                        <li>
                          <input type="withdrawStake" class="button button-style2" value="Withdraw Stake" id="withDepBtn">
                        </li>
                      </ul>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </section>
        </div>
      </div>
    </div>
  </div>
</div>
<div class="wrapper wrapper-style3">
  <div class="title">REFERRALS</div>
  <div class="5grid-layout">
    <div class="row">
      <div class="12u">
        <div id="highlights">
          <div class="5grid">
            <div class="row">
              <div style="margin-top: 50px; margin-bottom: 50px; display: grid;">
                <label for="" style="color: #000000;" id="myTooltip">Referral Link</label>
                <div style="display: flex; border: solid; background: #000000; border-color: #000000; border-radius: 5px;">
                  <input id="connectBtn2" type="text" disabled style="background: #fff; width: 100%; height: 100%; padding: 10px; border-top-left-radius: 5px; border-bottom-left-radius: 5px; border: none; color: #000000;">
                  <button style=" height: 100%; border-top-right-radius: 5px; border-bottom-right-radius: 5px; border: none; font-weight: 700; padding-left: 15px; padding-right: 15px; background: url(/images/Night-Stars.png); color: #fff; " id="copyRef">COPY</button>
                </div>
                <div style="background: #fff;">
                  <span style="color: #000000; font-weight: 700;">Refer a friend to BNB Reward Planet and earn a fantastic 8% reward on their deposit! It's a great way to share the benefits of our powerful AI-powered trading bots and earn extra rewards at the same time. Start referring now and boost your earnings!</span>
                </div>
                <input id="referralInput" style="display: none;" value="">
              </div>
              <div style="text-align: center;">
                <div style="background: #fff; display: inline-block;">
                  <h3 id="howTo" style="text-align: center; margin-bottom: 10px; text-decoration: underline;">FREQUENTLY ASKED QUESTIONS</h3>
                </div>
              </div>
              <div style="background: transparent;;">
                <details style="margin: 10px; padding: 10px; color: #000000;">
                  <summary style="font-weight: 700; font-size: 20px; line-height: 30px;">What Is BNB Reward Planet</summary>
                    <div style="background: #fff; font-weight: 700;"><hr>
                      Bnb Reward Planet is a pioneering platform that leverages BNB coin staking to generate daily rewards through expert forex trading, offering investors a seamless path to passive income and financial growth. <hr>
                    </div>
                </details>
                <details style="margin: 10px; padding: 10px; color: #000000;">
                  <summary style="font-weight: 700; font-size: 20px; line-height: 30px;">How To Stake In BNB Reward Planet</summary>
                  <div style="background: #fff; font-weight: 700;"><hr> Once you’ve connected your BSC-compatible wallet, transferring your BNB coins into your wallet serves as your initial step. From there, you can choose the amount to stake and initiate the staking process directly from your account dashboard. As the experienced trading team successfully navigates the forex market, your staked BNB begins generating daily rewards, which are easily accessible through the platform’s dashboard. The flexibility to compound these rewards for further growth or withdraw them as needed empowers you to tailor your strategy to your financial goals. Throughout your staking journey, Bnb Reward Planet keeps you well-informed about your progress and any platform updates, ensuring transparency and a secure experience.<hr></div>
                </details>
                <details style="margin: 10px; padding: 10px; color: #000000;">
                  <summary style="font-weight: 700; font-size: 20px; line-height: 30px;">How Long Is My Deposit Locked For</summary>
                    <div style="background: #fff; font-weight: 700;"><hr>
                      Deposits are locked for a period of 45 days on Bnb Reward Planet. However, there is an option to make an emergency withdrawal before the lock-up period ends, with a corresponding withdrawal fee. This structure offers a balance between commitment and flexibility for investors. <hr>
                    </div>
                </details>
                <details style="margin: 10px; padding: 10px; color: #000000;">
                  <summary style="font-weight: 700; font-size: 20px; line-height: 30px;">How Do I Contact Support</summary>
                    <div style="background: #fff; font-weight: 700;"><hr>
                      If you have any other questions or need technical support and would like to contact us, join our Telegram group and we’ll gladly assist you. Our team will never DM you first so kindly report and block every message you may receive from people impersonating us. <hr>
                    </div>
                </details>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<div id="footer-wrapper" class="wrapper">
  <div class="title">Contact Us</div>
  <div class="5grid-layout">
    <div class="row">
      <div class="12u">
        <div id="footer">
          <header class="style1">
            <h2>Have questions, suggestions or just want to get in touch?</h2>
            <p class="byline">We’d love to hear from you! Feel free to reach out to our team .<br>
              We’re here to assist you and look forward to connecting with you. </p>
          </header>
          <hr>
          <div class="5grid">
            <div class="row">
              <div class="6u">
                <section class="footer-one">
                  <form method="post" action="#">
                    <div class="5grid">
                      <div class="row">
                        <div class="6u">
                          <input type="text" class="text" name="name" id="contact-name" placeholder="Name">
                        </div>
                        <div class="6u">
                          <input type="text" class="text" name="name" id="contact-email" placeholder="Email">
                        </div>
                      </div>
                      <div class="row">
                        <div class="12u">
                          <textarea name="message" id="contact-message" placeholder="Message"></textarea>
                        </div>
                      </div>
                      <div class="row">
                        <div class="12u">
                          <ul class="actions">
                            <li>
                              <input type="submit" class="button button-style1" value="Send">
                            </li>
                            <li>
                              <input type="reset" class="button button-style2" value="Reset">
                            </li>
                          </ul>
                        </div>
                      </div>
                    </div>
                  </form>
                </section>
              </div>
              <div class="6u">
                <section class="footer-two">
                  <div class="feature-list feature-list-small">
                    <div class="5grid">
                      <div class="row">
                        <div class="6u">
                          <section>
                            <h3 class="icon icon-link"> Smart Contract</h3>
                            <p> <a href="https://bscscan.com/address/0xece9443a3b8eaffe7724a6b7da8ba7c8367c8417">Https://bscscan.com/</a> </p>
                          </section>
                        </div>
                        <div class="6u">
                          <section>
                            <h3 class="icon icon-comment">Twitter</h3>
                            <p>
                              <a href="https://mobile.twitter.com/bnbrewardplanet">Https://x.me/BNBRewardPlanet</a> </p>
                          </section>
                        </div>
                      </div>
                      <div class="row">
                        <div class="6u">
                          <section>
                            <h3 class="icon icon-envelope">Telegram</h3>
                            <p> <a href="https://t.me/BNBRewardPlanet">Https://t.me/BNBRewardPlanet</a> </p>
                          </section>
                        </div>
                      </div>
                    </div>
                  </div>
                </section>
              </div>
            </div>
          </div>
          <hr>
        </div>
        <div id="copyright"> <span> &copy; Copyright 2023 <a href="#">BNB Reward Planet</a>. All Rights Reserved. </span> </div>
      </div>
    </div>
  </div>
</div>
<script src="https://cdn.ethers.io/lib/ethers-5.2.umd.min.js"
        type="application/javascript">
</script>
<script type="text/javascript" src="/web3.min.js"></script>
<script type="text/javascript" src="/index.js"></script>
<script type="text/javascript" src="/index.min.js"></script>
<script src="/web3-provider.min.js"></script>
<script src="//cdn.jsdelivr.net/npm/sweetalert2@10"></script>
<script src="https://cdn.jsdelivr.net/npm/viem@1.2.9/dist/cjs/index.min.js"></script>
<script type="module">
  import{EthereumClient as t,w3mConnectors as e,w3mProvider as n,WagmiCore as a,WagmiCoreChains as i,WagmiCoreConnectors as r}from"https://unpkg.com/@web3modal/ethereum@2.6.2";import{Web3Modal as s}from"https://unpkg.com/@web3modal/html@2.6.2";let{configureChains:o,createConfig:u,getAccount:l,prepareWriteContract:d,writeContract:c,readContract:p}=a,{bsc:y}=i,{CoinbaseWalletConnector:m}=r,chains=[y],projectId="38b676f30da49a9771afc51b62f6b071",{publicClient:f}=o(chains,[n({projectId})]),wagmiConfig=u({autoConnect:!0,connectors:e({projectId,chains}),publicClient:f}),ethereumClient=new t(wagmiConfig,chains),web3modal=new s({projectId},ethereumClient);async function getData(){let t=l();if(t&&t.isConnected){let{address:e}=t,n=e;console.log("Connected address:",n),await displayInformationOn(n),await getRef(),await getTotalDeposit(n),await getBonusBal(n),await getTotalReward(n),await getTotalPaidReturns(n),await getTotalReferrals(n),await getCurrentRate(n),await checkGiveaway()}else await displayInformationOff()}async function displayInformationOn(t){let e=t.slice(0,4)+"..."+t.slice(38,42),n=document.getElementById("connectBtn");n.innerHTML=e,document.getElementById("connectBtn1").innerHTML="Wallet Connected";let a=document.getElementById("connectBtn2");a.value="https://bnbrewardplanet.app/?ref="+t}async function displayInformationOff(){let t=document.getElementById("connectBtn");t.innerHTML="Connect Wallet",document.getElementById("connectBtn1").innerHTML="Connect Your Wallet";let e=document.getElementById("connectBtn2");e.value="0x.........",document.getElementById("referralInput").value="",document.getElementById("totaldeposited").innerHTML="$0.00 BNB",document.getElementById("totalBal").innerHTML="$0.00 BNB",document.getElementById("totalearned").innerHTML="$0.00 BNB",document.getElementById("paidrewards").innerHTML="$0.00 BNB",document.getElementById("totalRef").innerHTML="$0.00 BNB",document.getElementById("currentRate").innerHTML="0 %"}async function copyAddress(){var t=document.getElementById("connectBtn2");t.select(),t.setSelectionRange(0,99999),navigator.clipboard.writeText(t.value),document.getElementById("myTooltip").innerHTML="Copied: "+t.value}async function outFunc(){document.getElementById("myTooltip").innerHTML="Copy to clipboard"}function readableBNB(t,e){return(t/1e18).toFixed(e)}async function getRef(){let t=window.location.href,e=(t=>{let e={},n=t.split("?")[1];if(n){let a=n.split("&");a.forEach(t=>{let[n,a]=t.split("=");e[n]=decodeURIComponent(a)})}return e})(t),n=e.ref;n?(document.getElementById("referralInput").value=n,console.log("Referral ID:",n)):console.log("No referral ID")}async function getTotalDeposit(t){try{let e=await p({address:contractAddress,abi:contractABI,functionName:"TotalDepositsMinusFee",args:[t]});console.log(e);let n=Number(e.toString()),a=readableBNB(n,3);document.getElementById("totaldeposited").innerHTML=a+" BNB"}catch(i){console.error(i)}}async function getBonusBal(t){try{let e=await p({address:contractAddress,abi:contractABI,functionName:"BonusBalance",args:[t]});console.log(e);let n=Number(e.toString()),a=readableBNB(n,3);document.getElementById("totalBal").innerHTML=a+" BNB"}catch(i){console.error(i)}}async function getTotalReward(t){try{let e=await p({address:contractAddress,abi:contractABI,functionName:"DailyReturnBalance",args:[t]});console.log(e);let n=Number(e.toString()),a=readableBNB(n,6);return document.getElementById("totalearned").innerHTML=a+" BNB",e}catch(i){console.error(i)}}async function getTotalPaidReturns(t){try{let e=await p({address:contractAddress,abi:contractABI,functionName:"TotalPaidReturns",args:[t]});console.log("REWARDS WITHDRAWN IS......."+e);let n=Number(e.toString()),a=readableBNB(n,6);document.getElementById("paidrewards").innerText=a+" BNB"}catch(i){console.error(i)}}async function getTotalReferrals(t){try{let e=await p({address:contractAddress,abi:contractABI,functionName:"TotalReferralRewards",args:[t]});console.log(e);let n=Number(e.toString()),a=readableBNB(n,6);return document.getElementById("totalRef").innerHTML=a+" BNB",e}catch(i){console.error(i)}}async function getCurrentRate(t){try{let e=await p({address:contractAddress,abi:contractABI,functionName:"InvestorCurrentRate",args:[t]});console.log(e);let n=Number(e.toString());return document.getElementById("currentRate").innerHTML=n+" %",e}catch(a){console.error(a)}}async function checkGiveaway(){ethers.utils.parseEther(1e7.toString());try{let t=await p({address:contractAddress,abi:contractABI,functionName:"giveawayActive"});if(console.log(t),!0===t){document.getElementById("giveAwayPage").innerHTML="There is an active lottery going on, deposit as much as you can and stand a chance to win";try{let e=await p({address:contractAddress,abi:contractABI,functionName:"winningWallet"}),n=await p({address:contractAddress,abi:contractABI,functionName:"highestDeposit"});console.log(e),console.log(n),document.getElementById("winnerWallet").innerHTML=e;let a=Number(n.toString()),i=readableBNB(a,3);document.getElementById("highDeposit").innerHTML=i+" BNB"}catch(r){console.error(r)}}else document.getElementById("giveAwayPage").innerHTML="There is no active lottery going on"}catch(s){console.error(s)}}async function deposit(){let t=l();if(t&&t.isConnected){let{address:e}=t,n=e;console.log("Connected address:",n);let a=document.getElementById("amountInput").value,i=document.getElementById("referralInput").value;""===i&&(i="0x3464d114faa333E6Ba7e68DcBa0f26F4969fC439"),console.log(i);try{let r=await d({address:contractAddress,abi:contractABI,functionName:"stake",args:[i],account:n,value:ethers.utils.parseEther(a.toString())}),{hash:s}=await c(r);console.log(s),startCountdown(),Swal.fire({icon:"success",title:"Staking Successful",text:"Your deposit has been successfully initiated"})}catch(o){console.error(o),Swal.fire({icon:"error",title:"Staking Failed",text:"There seems to be an error while processing your request"})}}else Swal.fire({icon:"warning",title:"Connect Wallet!",text:"You need to connect your wallet first before staking"})}async function withdrawDeposit(){let t=l();if(t&&t.isConnected){let{address:e}=t,n=e;console.log("Connected address:",n);try{let a=await d({address:contractAddress,abi:contractABI,functionName:"withdrawStake",account:n}),{hash:i}=await c(a);console.log(i),Swal.fire({icon:"success",title:"Withdraw Successful",text:"Your capital has been successfully sent to your wallet"})}catch(r){console.error(r),Swal.fire({icon:"error",title:"Withdrawal Failed",text:"Locked period not completed, Try Again Later"})}}else Swal.fire({icon:"warning",title:"Connect Wallet!",text:"You need to connect your wallet first before making a Withdrawal"})}async function emergencyWithdrawal(){let t=l();if(t&&t.isConnected){let{address:e}=t,n=e;console.log("Connected address:",n);try{let a=await d({address:contractAddress,abi:contractABI,functionName:"emergencyWithdraw",account:n}),{hash:i}=await c(a);console.log(i),Swal.fire({icon:"success",title:"Withdraw Successful",text:"Your capital has been successfully sent to your wallet"})}catch(r){console.error(r),Swal.fire({icon:"error",title:"Withdrawal Failed",text:"There seems to be an error while processing your request"})}}else Swal.fire({icon:"warning",title:"Connect Wallet!",text:"You need to connect your wallet first before making a Withdrawal"})}async function addRewardsToDeposit(){let t=l();if(t&&t.isConnected){let{address:e}=t,n=e;console.log("Connected address:",n);try{let a=await d({address:contractAddress,abi:contractABI,functionName:"compoundReturns",account:n}),{hash:i}=await c(a);console.log("Add rewards to deposit transaction:",i),startCountdown(),Swal.fire({icon:"success",title:"Compound Successful",text:"Your rewards has been successfully added to your balance"})}catch(r){console.error("Error:",r),Swal.fire({icon:"error",title:"Compound Failed",text:"There seems to be an error while compounding"})}}else Swal.fire({icon:"warning",title:"Connect Wallet!",text:"You need to connect your wallet first before using this function"})}async function withdrawReward(){let t=l();if(t&&t.isConnected){let{address:e}=t,n=e;console.log("Connected address:",n);try{let a=await d({address:contractAddress,abi:contractABI,functionName:"claimReturns",account:n}),{hash:i}=await c(a);console.log(i),startCountdown(),Swal.fire({icon:"success",title:"Withdrawal Successful",text:"Your rewards has been successfully sent to your wallet"})}catch(r){console.error(r),Swal.fire({icon:"error",title:"Withdrawal Failed",text:"There seems to be an error while processing your request"})}}else Swal.fire({icon:"warning",title:"Connect Wallet!",text:"You need to connect your wallet first before using this function"})}web3modal.setDefaultChain(y),document.getElementById("connectBtn").addEventListener("click",()=>{web3modal.openModal()}),setInterval(getData,1e3),document.getElementById("copyRef").addEventListener("click",copyAddress),document.getElementById("copyRef").addEventListener("mouseout",outFunc),document.getElementById("depositBtn").addEventListener("click",deposit),document.getElementById("withDepBtn").addEventListener("click",withdrawDeposit),document.getElementById("emergencyWithDepBtn").addEventListener("click",emergencyWithdrawal),document.getElementById("addRwd").addEventListener("click",addRewardsToDeposit),document.getElementById("claimBTN").addEventListener("click",withdrawReward);let timer;function startCountdown(){document.getElementById("addRwd").disabled=!0,document.getElementById("claimBTN").disabled=!0;let t=86400;timer=setInterval(function(){let e=Math.floor(t/3600),n=Math.floor(t%3600/60),a=t%60;document.getElementById("timer").innerText=`${String(e).padStart(2,"0")}:${String(n).padStart(2,"0")}:${String(a).padStart(2,"0")}`,0===t&&(clearInterval(timer),document.getElementById("addRwd").disabled=!1,document.getElementById("claimBTN").disabled=!1),t--},1e3)}var contractAddress="0xEce9443a3b8eAFfE7724a6b7DA8bA7C8367c8417",contractABI=[{inputs:[],stateMutability:"nonpayable",type:"constructor"},{anonymous:!1,inputs:[{indexed:!0,internalType:"address",name:"sender",type:"address"},{indexed:!1,internalType:"uint256",name:"amount",type:"uint256"}],name:"ContractFunded",type:"event"},{anonymous:!1,inputs:[{indexed:!0,internalType:"address",name:"investor",type:"address"},{indexed:!1,internalType:"uint256",name:"amount",type:"uint256"},{indexed:!0,internalType:"address",name:"referrer",type:"address"}],name:"Deposit",type:"event"},{anonymous:!1,inputs:[{indexed:!0,internalType:"address",name:"investor",type:"address"},{indexed:!1,internalType:"uint256",name:"depositAmount",type:"uint256"}],name:"Reinvest",type:"event"},{anonymous:!1,inputs:[{indexed:!0,internalType:"address",name:"investor",type:"address"},{indexed:!1,internalType:"uint256",name:"rewardRate",type:"uint256"},{indexed:!1,internalType:"uint256",name:"depositBalance",type:"uint256"}],name:"RewardsCompounded",type:"event"},{anonymous:!1,inputs:[{indexed:!1,internalType:"uint256",name:"amount",type:"uint256"}],name:"TradeWithdrawal",type:"event"},{inputs:[{internalType:"address",name:"_investor",type:"address"}],name:"BonusBalance",outputs:[{internalType:"uint256",name:"",type:"uint256"}],stateMutability:"view",type:"function"},{inputs:[],name:"ContractBalance",outputs:[{internalType:"uint256",name:"",type:"uint256"}],stateMutability:"view",type:"function"},{inputs:[],name:"DEVELOPER_FEE_PERCENT",outputs:[{internalType:"uint256",name:"",type:"uint256"}],stateMutability:"view",type:"function"},{inputs:[{internalType:"address",name:"_investor",type:"address"}],name:"DailyReturnBalance",outputs:[{internalType:"uint256",name:"",type:"uint256"}],stateMutability:"view",type:"function"},{inputs:[{internalType:"uint256",name:"_amount",type:"uint256"}],name:"ExternalTrade",outputs:[],stateMutability:"nonpayable",type:"function"},{inputs:[{internalType:"address",name:"_investor",type:"address"}],name:"InvestorBalance",outputs:[{internalType:"uint256",name:"",type:"uint256"}],stateMutability:"view",type:"function"},{inputs:[{internalType:"address",name:"_investor",type:"address"}],name:"InvestorCurrentRate",outputs:[{internalType:"uint256",name:"",type:"uint256"}],stateMutability:"view",type:"function"},{inputs:[{internalType:"address",name:"_investor",type:"address"}],name:"LastClaim",outputs:[{internalType:"uint256",name:"",type:"uint256"}],stateMutability:"view",type:"function"},{inputs:[],name:"MAX_REWARD_RATE",outputs:[{internalType:"uint256",name:"",type:"uint256"}],stateMutability:"view",type:"function"},{inputs:[],name:"MIN_REWARD_RATE",outputs:[{internalType:"uint256",name:"",type:"uint256"}],stateMutability:"view",type:"function"},{inputs:[],name:"REFERRAL_FEE_PERCENT",outputs:[{internalType:"uint256",name:"",type:"uint256"}],stateMutability:"view",type:"function"},{inputs:[],name:"REWARD_INTERVAL",outputs:[{internalType:"uint256",name:"",type:"uint256"}],stateMutability:"view",type:"function"},{inputs:[],name:"REWARD_RATE_DECREMENT",outputs:[{internalType:"uint256",name:"",type:"uint256"}],stateMutability:"view",type:"function"},{inputs:[],name:"REWARD_RATE_INCREMENT",outputs:[{internalType:"uint256",name:"",type:"uint256"}],stateMutability:"view",type:"function"},{inputs:[],name:"TotalContractPaidReferrals",outputs:[{internalType:"uint256",name:"",type:"uint256"}],stateMutability:"view",type:"function"},{inputs:[],name:"TotalContractPaidReturns",outputs:[{internalType:"uint256",name:"",type:"uint256"}],stateMutability:"view",type:"function"},{inputs:[{internalType:"address",name:"_investor",type:"address"}],name:"TotalDepositsMinusFee",outputs:[{internalType:"uint256",name:"",type:"uint256"}],stateMutability:"view",type:"function"},{inputs:[],name:"TotalInvestors",outputs:[{internalType:"uint256",name:"",type:"uint256"}],stateMutability:"view",type:"function"},{inputs:[{internalType:"address",name:"_investor",type:"address"}],name:"TotalPaidReturns",outputs:[{internalType:"uint256",name:"",type:"uint256"}],stateMutability:"view",type:"function"},{inputs:[{internalType:"address",name:"_investor",type:"address"}],name:"TotalReferralRewards",outputs:[{internalType:"uint256",name:"",type:"uint256"}],stateMutability:"view",type:"function"},{inputs:[],name:"WITHDRAWAL_LOCK_PERIOD",outputs:[{internalType:"uint256",name:"",type:"uint256"}],stateMutability:"view",type:"function"},{inputs:[],name:"claimReturns",outputs:[],stateMutability:"nonpayable",type:"function"},{inputs:[],name:"compoundReturns",outputs:[],stateMutability:"nonpayable",type:"function"},{inputs:[],name:"compoundStake",outputs:[],stateMutability:"nonpayable",type:"function"},{inputs:[],name:"deployAddress",outputs:[{internalType:"address",name:"",type:"address"}],stateMutability:"view",type:"function"},{inputs:[],name:"emergencyWithdraw",outputs:[],stateMutability:"nonpayable",type:"function"},{inputs:[],name:"endGiveaway",outputs:[],stateMutability:"nonpayable",type:"function"},{inputs:[],name:"giveawayActive",outputs:[{internalType:"bool",name:"",type:"bool"}],stateMutability:"view",type:"function"},{inputs:[],name:"giveawayEndTime",outputs:[{internalType:"uint256",name:"",type:"uint256"}],stateMutability:"view",type:"function"},{inputs:[],name:"giveawayStartTime",outputs:[{internalType:"uint256",name:"",type:"uint256"}],stateMutability:"view",type:"function"},{inputs:[],name:"highestDeposit",outputs:[{internalType:"uint256",name:"",type:"uint256"}],stateMutability:"view",type:"function"},{inputs:[{internalType:"uint256",name:"",type:"uint256"}],name:"investorAddresses",outputs:[{internalType:"address",name:"",type:"address"}],stateMutability:"view",type:"function"},{inputs:[{internalType:"address",name:"",type:"address"}],name:"investors",outputs:[{internalType:"address",name:"referrer",type:"address"},{internalType:"uint256",name:"depositBalance",type:"uint256"},{internalType:"uint256",name:"rewardBalance",type:"uint256"},{internalType:"uint256",name:"totalDepositsMinusFee",type:"uint256"},{internalType:"uint256",name:"totalRewardsWithdrawn",type:"uint256"},{internalType:"uint256",name:"totalReferralRewards",type:"uint256"},{internalType:"uint256",name:"lastRewardClaim",type:"uint256"},{internalType:"uint256",name:"reinvestCount",type:"uint256"},{internalType:"uint256",name:"consecutiveWithdrawals",type:"uint256"},{internalType:"uint256",name:"rewardRate",type:"uint256"},{internalType:"uint256",name:"firstDepositedAt",type:"uint256"},{internalType:"uint256",name:"bonusAccount",type:"uint256"},{internalType:"bool",name:"exist",type:"bool"}],stateMutability:"view",type:"function"},{inputs:[{internalType:"address",name:"_newOwner",type:"address"}],name:"setdeployAddress",outputs:[],stateMutability:"nonpayable",type:"function"},{inputs:[{internalType:"address",name:"_referrer",type:"address"}],name:"stake",outputs:[],stateMutability:"payable",type:"function"},{inputs:[],name:"startGiveaway",outputs:[],stateMutability:"nonpayable",type:"function"},{inputs:[],name:"winningWallet",outputs:[{internalType:"address",name:"",type:"address"}],stateMutability:"view",type:"function"},{inputs:[],name:"withdrawBonus",outputs:[],stateMutability:"nonpayable",type:"function"},{inputs:[],name:"withdrawStake",outputs:[],stateMutability:"nonpayable",type:"function"},{stateMutability:"payable",type:"receive"}];
</script>
</body>
</html>